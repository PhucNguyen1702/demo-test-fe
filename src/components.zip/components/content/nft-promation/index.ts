export { default as NftPromotion } from "./nft-promotion";
