export { default as NftCollections } from "./nft-collection";
